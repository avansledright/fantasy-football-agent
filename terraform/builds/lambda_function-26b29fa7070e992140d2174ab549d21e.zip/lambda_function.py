# lambda_function.py
import json
import os
from strands import Agent
from strands.models import BedrockModel
from tools.fantasy_draft_tool import get_best_available_player

# Load the draft system prompt
with open("prompts/draft_agent_prompt.txt") as f:
    DRAFT_PROMPT = f.read()

# Configure the Bedrock model (Claude 3.5 Haiku by default)
bedrock_model = BedrockModel(
    model_id=os.environ.get("BEDROCK_MODEL_ID", "anthropic.claude-3-5-haiku-20240620-v1:0"),
    max_tokens=4000,
    temperature=0.0,
)

# Create the agent
agent = Agent(
    model=bedrock_model,
    system_prompt=DRAFT_PROMPT,
    tools=[get_best_available_player]
)

def lambda_handler(event, context):
    print(f"DEBUG: Raw event: {json.dumps(event)}")
    
    # Handle different event structures (API Gateway vs direct invoke)
    if 'body' in event:
        # API Gateway format
        if isinstance(event['body'], str):
            body = json.loads(event['body'])
        else:
            body = event['body']
    else:
        # Direct invoke format
        body = event
    
    print(f"DEBUG: Parsed body: {json.dumps(body)}")
    
    # Extract parameters with defaults
    team_needs = body.get("team_needs", {
        "QB": 2, "RB": 2, "WR": 2, "TE": 1, "DEF": 1, "K": 1, "FLEX": 1
    })
    already_drafted = body.get("already_drafted", [])
    scoring_format = body.get("scoring_format", "ppr")
    league_size = body.get("league_size", 12)
    
    print(f"DEBUG: team_needs = {team_needs}")
    print(f"DEBUG: already_drafted = {already_drafted} (count: {len(already_drafted)})")
    print(f"DEBUG: scoring_format = {scoring_format}")
    print(f"DEBUG: league_size = {league_size}")

    # Build the query for the agent
    needs_description = []
    for pos, count in team_needs.items():
        if count > 0:
            needs_description.append(f"{count} {pos}")
    
    if needs_description:
        needs_text = f"My current team needs: {', '.join(needs_description)}."
    else:
        needs_text = "My roster is complete, looking for best available player."
    
    drafted_text = f"Already drafted player IDs: {already_drafted}." if already_drafted else "No players drafted yet."
    
    query = f"{needs_text} {drafted_text} Who should I pick next in my {scoring_format.upper()} league?"
    
    print(f"DEBUG: Agent query: {query}")

    # Call the agent
    result = agent(query)
    print(f"DEBUG: Agent result type: {type(result)}")
    print(f"DEBUG: Agent result: {result}")
    
    # Safely extract output text
    output_text = getattr(result, "text", None) or \
                  getattr(result, "output", None) or \
                  getattr(result, "response", {}).get("output_text")

    # Fallback: stringify whole result
    if not output_text:
        output_text = str(result)

    response_body = {
        "recommendation": output_text,
        "tool_calls": getattr(result, "tool_calls", []),
        "debug_info": {
            "team_needs": team_needs,
            "already_drafted_count": len(already_drafted),
            "scoring_format": scoring_format,
            "league_size": league_size
        }
    }

    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type"
        },
        "body": json.dumps(response_body)
    }