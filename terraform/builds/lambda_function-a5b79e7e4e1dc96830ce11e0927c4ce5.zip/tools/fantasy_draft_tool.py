# tools/fantasy_draft_tool.py
import boto3
from strands import tool
from decimal import Decimal
from typing import Dict, List, Optional

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("2025-2026-fantasy-football-player-data")

# Define replacement-level baselines for different league sizes
REPLACEMENT_VALUES = {
    12: {  # 12-team league
        "QB": 280,   # QB12 baseline
        "RB": 180,   # RB24 baseline (2 per team)
        "WR": 170,   # WR24 baseline
        "TE": 110,   # TE12 baseline
        "K": 90,     # K12 baseline
        "DEF": 85    # DEF12 baseline
    }
}

# Positional scarcity multipliers (higher = more scarce)
SCARCITY_FACTORS = {
    "QB": 0.8,   # Less scarce due to streaming
    "RB": 1.3,   # Most scarce
    "WR": 1.1,   # Moderately scarce
    "TE": 1.2,   # Very scarce after top tier
    "K": 0.6,    # Least important
    "DEF": 0.7   # Streamable
}

def scan_players_by_season(season: int = 2024, season_type: str = "REG"):
    """Retrieve players from most recent regular season."""
    try:
        response = table.scan(
            FilterExpression="season = :season AND season_type = :season_type",
            ExpressionAttributeValues={
                ":season": season,
                ":season_type": season_type
            }
        )
        
        players = response.get("Items", [])
        
        # Handle pagination
        while "LastEvaluatedKey" in response:
            response = table.scan(
                FilterExpression="season = :season AND season_type = :season_type",
                ExpressionAttributeValues={
                    ":season": season,
                    ":season_type": season_type
                },
                ExclusiveStartKey=response["LastEvaluatedKey"]
            )
            players.extend(response.get("Items", []))
            
        return players
    except Exception as e:
        print(f"Error scanning players: {e}")
        return []

def aggregate_player_stats(players: List[Dict]) -> Dict[str, Dict]:
    """Aggregate season stats by player."""
    player_stats = {}
    
    for player in players:
        player_id = player.get("player_id")
        if not player_id:
            continue
            
        if player_id not in player_stats:
            player_stats[player_id] = {
                "player_id": player_id,
                "player_display_name": player.get("player_display_name", "Unknown"),
                "position": player.get("position", ""),
                "team": player.get("team", ""),
                "games_played": 0,
                "fantasy_points_ppr": 0,
                "fantasy_points": 0,
                "rushing_yards": 0,
                "receiving_yards": 0,
                "passing_yards": 0,
                "total_tds": 0,
                "receptions": 0
            }
        
        # Aggregate stats
        stats = player_stats[player_id]
        stats["games_played"] += 1
        stats["fantasy_points_ppr"] += float(player.get("fantasy_points_ppr", 0))
        stats["fantasy_points"] += float(player.get("fantasy_points", 0))
        stats["rushing_yards"] += float(player.get("rushing_yards", 0))
        stats["receiving_yards"] += float(player.get("receiving_yards", 0))
        stats["passing_yards"] += float(player.get("passing_yards", 0))
        stats["receptions"] += float(player.get("receptions", 0))
        
        # Calculate total TDs
        rushing_tds = float(player.get("rushing_tds", 0))
        receiving_tds = float(player.get("receiving_tds", 0))
        passing_tds = float(player.get("passing_tds", 0))
        stats["total_tds"] += rushing_tds + receiving_tds + passing_tds
    
    return player_stats

def calculate_team_needs_priority(team_needs: Dict[str, int]) -> Dict[str, float]:
    """Calculate priority multiplier based on remaining needs."""
    total_spots = sum(team_needs.values())
    if total_spots == 0:
        return {pos: 0.1 for pos in team_needs.keys()}  # Draft BPA if roster full
    
    priority = {}
    for position, needed in team_needs.items():
        if needed > 0:
            # Higher priority for positions with more spots needed
            urgency = needed / max(total_spots, 1)
            priority[position] = 1.0 + (urgency * 2)  # 1.0 to 3.0 range
        else:
            priority[position] = 0.2  # Very low but not zero for FLEX consideration
    
    return priority

def is_flex_eligible(position: str) -> bool:
    """Check if player is FLEX eligible (RB, WR, TE)."""
    return position in ["RB", "WR", "TE"]

def calculate_player_score(player: Dict, team_needs: Dict[str, int], 
                         drafted_players: List[str], league_size: int = 12) -> float:
    """Calculate comprehensive player score."""
    
    player_id = player["player_id"]
    position = player["position"]
    ppr_points = player["fantasy_points_ppr"]
    games = max(player["games_played"], 1)  # Avoid division by zero
    
    # Skip drafted players
    if player_id in drafted_players:
        return -9999
    
    # Skip players with no fantasy relevance
    if ppr_points < 20:  # Arbitrary cutoff for relevant players
        return -9999
    
    # Calculate points per game for consistency
    ppg = ppr_points / games
    
    # Value Over Replacement Player (VORP)
    replacement_value = REPLACEMENT_VALUES[league_size].get(position, 50)
    vorp = ppr_points - replacement_value
    
    # Positional scarcity
    scarcity = SCARCITY_FACTORS.get(position, 1.0)
    
    # Team needs priority
    needs_priority = calculate_team_needs_priority(team_needs)
    position_priority = needs_priority.get(position, 0.1)
    
    # FLEX consideration - if RB/WR/TE and FLEX spot available
    flex_bonus = 0
    if is_flex_eligible(position) and team_needs.get("FLEX", 0) > 0:
        flex_bonus = 0.2
    
    # Games played bonus (availability/durability)
    games_bonus = min(games / 17, 1.0) * 0.1  # Up to 10% bonus for full season
    
    # Final composite score
    score = (
        vorp * 0.5 +                    # 50% - Raw value over replacement
        ppg * position_priority * 0.3 + # 30% - PPG weighted by need
        ppr_points * scarcity * 0.2 +   # 20% - Total points with scarcity
        flex_bonus * ppr_points +       # Bonus for FLEX eligibility
        games_bonus * ppr_points        # Durability bonus
    )
    
    return score

@tool
def get_best_available_player(team_needs: dict, already_drafted: list, 
                            league_size: int = 12, top_n: int = 5) -> dict:
    """
    Recommend the best available fantasy football players.
    
    Args:
        team_needs (dict): Remaining positions to fill (e.g., {"QB": 1, "RB": 2, "WR": 2, "TE": 1, "DEF": 1, "K": 1, "FLEX": 1})
        already_drafted (list): List of player IDs already drafted
        league_size (int): Number of teams in league (default 12)
        top_n (int): Number of top recommendations to return (default 5)
    
    Returns:
        dict: Top player recommendations with analysis
    """
    
    try:
        # Get latest season data
        players = scan_players_by_season()
        if not players:
            return {"error": "No player data found"}
        
        # Aggregate season totals
        aggregated_players = aggregate_player_stats(players)
        if not aggregated_players:
            return {"error": "No aggregated player data"}
        
        # Convert to list and filter available players
        available_players = [
            player for player in aggregated_players.values()
            if player["player_id"] not in already_drafted and 
            player["fantasy_points_ppr"] > 0
        ]
        
        if not available_players:
            return {"error": "No available players remaining"}
        
        # Score all players
        scored_players = []
        for player in available_players:
            score = calculate_player_score(player, team_needs, already_drafted, league_size)
            if score > -9999:  # Only include valid players
                scored_players.append({
                    **player,
                    "draft_score": round(score, 2),
                    "points_per_game": round(player["fantasy_points_ppr"] / max(player["games_played"], 1), 1)
                })
        
        # Sort by score and get top recommendations
        scored_players.sort(key=lambda x: x["draft_score"], reverse=True)
        top_players = scored_players[:top_n]
        
        # Generate analysis for top pick
        if top_players:
            best_player = top_players[0]
            position = best_player["position"]
            needs_analysis = f"Fills {position} need" if team_needs.get(position, 0) > 0 else "Best available player"
            
            analysis = {
                "primary_recommendation": {
                    "player_id": best_player["player_id"],
                    "name": best_player["player_display_name"],
                    "position": position,
                    "team": best_player["team"],
                    "fantasy_points_ppr": best_player["fantasy_points_ppr"],
                    "points_per_game": best_player["points_per_game"],
                    "games_played": best_player["games_played"],
                    "draft_score": best_player["draft_score"],
                    "reasoning": f"{needs_analysis}. Scored {best_player['fantasy_points_ppr']} PPR points over {best_player['games_played']} games ({best_player['points_per_game']} PPG)."
                },
                "alternatives": [
                    {
                        "name": p["player_display_name"],
                        "position": p["position"],
                        "team": p["team"],
                        "fantasy_points_ppr": p["fantasy_points_ppr"],
                        "points_per_game": p["points_per_game"],
                        "draft_score": p["draft_score"]
                    }
                    for p in top_players[1:]
                ],
                "remaining_needs": team_needs,
                "total_available_players": len(available_players)
            }
            
            return analysis
        else:
            return {"error": "No scoreable players found"}
            
    except Exception as e:
        return {"error": f"Tool execution failed: {str(e)}"}